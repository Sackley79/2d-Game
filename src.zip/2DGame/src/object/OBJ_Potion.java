package object;

import entiry.Entiry;
import main.GamePanel;

public class OBJ_Potion extends Entiry {

	public OBJ_Potion(GamePanel gp) {
		super(gp);
		name = "Health Potion";
		
		image = setup("/objects/HealthPot 16x16.png.png", gp.tileSize,gp.tileSize);
	}

}
