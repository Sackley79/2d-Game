package object;



import entiry.Entiry;
import main.GamePanel;


public class OBJ_Heart extends Entiry{

	public OBJ_Heart(GamePanel gp) {
		super(gp);
		type = 4;
		name = "Heart";
		
		
		image = setup("/objects/Full_Heart.png", gp.tileSize,gp.tileSize);
		image2 = setup("/objects/Half_Heart.png", gp.tileSize,gp.tileSize);
		image3 = setup("/objects/Empty_Heart.png", gp.tileSize,gp.tileSize);
		
	
	
	
	}
	
}

