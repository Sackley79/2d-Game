package object;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import entiry.Entiry;
import main.GamePanel;

public class OBJ_Chest extends Entiry{
	GamePanel gp;
	
		
	
	public OBJ_Chest(GamePanel gp) {
		super(gp);
		chestInv = new ArrayList<>();
		name = "Chest";
		
	
	down1 = setup("/objects/chest.png", gp.tileSize,gp.tileSize);
	Collision = true;
	}
	
	public void setInv(GamePanel gp) {//, ArrayList<Entiry> chestInv) {
		this.gp=gp;
//		chestInv.add(entiry);
		
		
		List<Entiry> items = new ArrayList<>();
    	items.add(gp.player.axe);
    	items.add(gp.player.dagger);
    	items.add(gp.player.spade);
    	items.add(gp.player.sword);
    	items.add(gp.player.potion);
    	items.add(gp.player.potion);
    	items.add(gp.player.potion);
    	items.add(gp.player.potion);
    	items.add(gp.player.potion);
    	
    	
    	items = items.stream().collect(Collectors.toList());
    			Collections.shuffle(items);
    	
    	items.stream().limit(3);
    	for(int i=0; i<3;i++) {
    		chestInv.add(items.get(i));
    	}
	}
	public ArrayList<Entiry> getChest(){//(ArrayList<Entiry> chestInv){
		return chestInv;
	
}
	
	
}


