package object;





public class Weapon {
	private String name;
	private String wepImage;
	private int wepDamage;
	
	 public Weapon(String name, String wepImage, int wepDamage) {
	    this.name = name;
	    this.wepImage=wepImage;
	    this.wepDamage=wepDamage;
	   
}
	 
	 public String getName() {
		    return name;
		}

	 public void setName(String name) {
		    this.name = name;
		}
	 public String getImage() {
		 return wepImage;
	 }
	 public void setWepImage(String wepImage) {
		 this.wepImage=wepImage;
	 }
	 public int getDamage() {
		 return wepDamage;
	 }
	 public void setDamage(int wepDamage) {
		 this.wepDamage=wepDamage;
	 }
}

