package object;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;



import entiry.Entiry;
import main.GamePanel;

public class OBJ_Weapons extends Entiry{

	GamePanel gp;

	
	
	public OBJ_Weapons(GamePanel gp, int i) {
		super(gp);
		type = 3;
		List<Weapon> weaponList= weaponList();
		  weaponList.sort( new Comparator<Weapon>() {

			@Override
			public int compare(Weapon o1, Weapon o2) {
				return Integer.compare(o1.getDamage(), o2.getDamage());
			}
          });

		name = weaponList.get(i).getName();
		image = setup(weaponList.get(i).getImage(), gp.tileSize, gp.tileSize); 
		damage = weaponList.get(i).getDamage();
		
	
	}
	
	public static List<Weapon> weaponList(){
		List<Weapon> wepList = new ArrayList<>();
		
		wepList.add(new Weapon("Sword","/objects/baseSword.png",3));
		wepList.add(new Weapon("Heavy Axe","/objects/BattleAxe Brown Handle.png.png",4));
		wepList.add(new Weapon("Dagger","/objects/Dagger.png.png",1));
		wepList.add(new Weapon("Spade","/objects/Spade.png.png",2));


		
		return wepList;
		
	}
	

}
