package Enemy;

import java.util.Random;

import entiry.Entiry;
import main.GamePanel;

public class Enemy_Dragon extends Entiry {

	GamePanel gp;
	public Enemy_Dragon(GamePanel gp) {
		super(gp);
		this.gp=gp;
		type = 2;
		name = "Dragon";
		speed = 2;
		maxLife = 20;
		life = maxLife;
		Collision = true;
		damage = 5;
		
		solidArea.x = 5;
		solidArea.y = 5;
		solidArea.width = 42;
		solidArea.height = 42;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		getImage();
	}
	
	public void getImage() {
		
			try {
			
				up1= setup("/Enemy/GreyDragon1.png", gp.tileSize*2,gp.tileSize*2);
				down1= setup("/Enemy/GreyDragon1.png", gp.tileSize*2,gp.tileSize*2);
				left1= setup("/Enemy/GreyDragon2.png", gp.tileSize*2,gp.tileSize*2);
				right1= setup("/Enemy/GreyDragon2.png", gp.tileSize*2,gp.tileSize*2);
				up2= setup("/Enemy/GreyDragon2.png", gp.tileSize*2,gp.tileSize*2);
				down2= setup("/Enemy/GreyDragon2.png", gp.tileSize*2,gp.tileSize*2);
				left2= setup("/Enemy/GreyDragon2.png", gp.tileSize*2,gp.tileSize*2);
				right2= setup("/Enemy/GreyDragon1.png", gp.tileSize*2,gp.tileSize*2);


			
			
		}
		catch(Exception e) {
			
			
		}
		
	
		
	}
	
	public void setAction() {
		
		actionLockCounter++;
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1;
		
		
		if( i<25) {
			direction = "up";
		}
		if( i>25 && i<50) {
			direction = "left";
		}
		if( i>50 && i<75) {
			direction = "right";
		}
		if( i>75 && i<100) {
			direction = "down";
		}
		actionLockCounter=0;
		
	}
	}
	
public void enemyReact() {
		
		actionLockCounter = 0;
		 switch(gp.player.direction) {
		 case"up":
			 direction = "down";
			break;
		case"down":
			 direction = "up";
			break;
		case "left":
			 direction = "right";
			break;
		case"right":
			 direction = "left";
			break;
		 }
		
		
	}


	

	
	}


