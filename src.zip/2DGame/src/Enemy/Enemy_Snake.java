package Enemy;


import java.util.Random;

import entiry.Entiry;
import main.GamePanel;

public class Enemy_Snake extends Entiry{
	GamePanel gp;
	public Enemy_Snake(GamePanel gp) {
		super(gp);
		this.gp=gp;
		type = 2;
		name = "Snake";
		speed = 5;
		maxLife = 2;
		life = maxLife;
		Collision = true;
		damage = 1;
		
		solidArea.x = 5;
		solidArea.y = 8;
		solidArea.width = 20;
		solidArea.height = 20;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		getImage();
	}
	
	public void getImage() {
		
			try {
			
				up1= setup("/Enemy/Snake1.png", gp.tileSize,gp.tileSize);
				down1= setup("/Enemy/Snake1.png", gp.tileSize,gp.tileSize);
				left1= setup("/Enemy/Snake2.png", gp.tileSize,gp.tileSize);
				right1= setup("/Enemy/Snake1.png", gp.tileSize,gp.tileSize);
				up2= setup("/Enemy/Snake2.png", gp.tileSize,gp.tileSize);
				down2= setup("/Enemy/Snake2.png", gp.tileSize,gp.tileSize);
				left2= setup("/Enemy/Snake2.png", gp.tileSize,gp.tileSize);
				right2= setup("/Enemy/Snake1.png", gp.tileSize,gp.tileSize);


			
			
		}
		catch(Exception e) {
			
			
		}
		
	
		
	}
	
	public void setAction() {
		
		actionLockCounter++;
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1;
		
		
		if( i<25) {
			direction = "up";
		}
		if( i>25 && i<50) {
			direction = "left";
		}
		if( i>50 && i<75) {
			direction = "right";
		}
		if( i>75 && i<100) {
			direction = "down";
		}
		actionLockCounter=0;
		
	}
	}
	
public void enemyReact() {
		
		actionLockCounter = 0;
		 switch(gp.player.direction) {
		 case"up":
			 direction = "down";
			break;
		case"down":
			 direction = "up";
			break;
		case "left":
			 direction = "right";
			break;
		case"right":
			 direction = "left";
			break;
		 }
		
		
	}

}

