package entiry;






import main.GamePanel;

public class NPC extends Entiry {

	public NPC(GamePanel gp) {
		super(gp);
		
		getNPCImage();
		setDialouge();
	}
	public void getNPCImage() {
		try {
			
			down1 = setup("/npc/king.png.png", gp.tileSize,gp.tileSize);
			
			
		}
		catch(Exception e) {
			
			
		}
	}
	public void setDialouge() {
		
		dialouge[0] = "Sup bro wanna go kill everything for me \nthanks";
		dialouge[1] = "Go nuts I dont care what you have to do to kill \neveything";
		dialouge[2] = "You dont wanna know why i want them dead";
		dialouge[3] = "Ok I'll tell you its cause I just hate \neveything that isn't human";
	}
	
	public void speak() {
	
		if(dialouge[dialougeIndex] == null) {
			dialougeIndex = 0;
			
		}
		gp.ui.currentDialouge = dialouge[dialougeIndex];
		dialougeIndex++;
		
		
	}
		
}
