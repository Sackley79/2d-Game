package entiry;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.OBJSetter;
import main.UtilityTool;
import object.OBJ_Potion;
import object.OBJ_Weapons;

public class Entiry {

	GamePanel gp;
	OBJSetter os;
	
	public int worldX, worldY;
	public int speed;
	
	public BufferedImage up1, up2, down1, down2, right1, right2, left1, left2, king;
	public BufferedImage attackUp, attackDown, attackLeft, attackRight;
	public String direction = "down";
	

	
	public int spriteCounter = 0;
	public int standCounter = 0;
	public int spriteNum = 1;
	
	public Rectangle solidArea = new Rectangle(0,0,48,48);
	public boolean collisionOn = false;
	
	public Rectangle attackArea = new Rectangle(0, 0,0 ,0);
	
	public int solidAreaDefaultX;
	public int solidAreaDefaultY;
	
	public String dialouge[]  = new String[5];
	public int dialougeIndex = 0;
	
	public int actionLockCounter = 0 ;
	
	public boolean invincible = false;
	public int invincCount;
	
	//char stat
	public int maxLife;
	public int life;
	public Entiry currentWeapon;
	public boolean alive = true;
	public boolean dead = false;
	public int deadCount;
	
	public BufferedImage image, image2, image3;
	public String name;
	public boolean Collision = false;
	public int damage;
	public int type;
	
	public ArrayList<Entiry> chestInv ;
	
	boolean attacking = false;
	
	public void setAction() {}
	public void enemyReact() {};
	public void update() {
		setAction();
		
		collisionOn = false;
		gp.cChecker.checkBG(this);
		gp.cChecker.checkObj(this, false);
		gp.cChecker.checkEntiry(this, gp.npc);
		gp.cChecker.checkEntiry(this, gp.enemy);
		boolean contactPlayer = gp.cChecker.checkPlayer(this);
		
		if(this.type == 2 && contactPlayer == true) {
			if(gp.player.invincible == false) {
				gp.player.life -= damage;
				gp.player.invincible = true;
			}
		}
		
		 if(collisionOn == false ) {
			 switch(direction) {
			 case"up":
				 worldY -= speed;
				break;
			case"down":
				worldY += speed;
				break;
			case "left":
				worldX -= speed;
				break;
			case"right":
				worldX += speed;
				break;
			 }
		 }
		
		 spriteCounter++;
		 if(spriteCounter>10) {
			 if(spriteNum == 1) {
				 spriteNum=2;
			 }
			 else if(spriteNum == 2) {
				 spriteNum=1;
			 }
			 spriteCounter = 0;
		 }
		 
		 if(invincible == true) {
				invincCount ++;
				if(invincCount > 30) {
					invincible = false;
					invincCount = 0;
				}
			}
	}
	
	
	public Entiry(GamePanel gp) {
		this.gp=gp;
	}

	public void speak() {
		
	}
	//public void drawNPC(Graphics2D g2) {
//		BufferedImage image = king;
//	
//		int screenX = worldX - gp.player.worldX + gp.player.screenX;
//		int screenY = worldY - gp.player.worldY + gp.player.screenY;
//		if (worldX + gp.tileSize > gp.player.worldX - gp.player.screenX && 
//				worldX - gp.tileSize< gp.player.worldX + gp.player.screenX && 
//				worldY + gp.tileSize>gp.player.worldY - gp.player.screenY &&
//				worldY - gp.tileSize< gp.player.worldY +  gp.player.screenY) {
//			g2.drawImage(image, screenX, screenY,gp.tileSize, gp.tileSize, null);
//		}
//	}

	
	public void draw(Graphics2D g2) {
		BufferedImage image = null;
	
		int screenX = worldX - gp.player.worldX + gp.player.screenX;
		int screenY = worldY - gp.player.worldY + gp.player.screenY;
		if (worldX + gp.tileSize > gp.player.worldX - gp.player.screenX && 
				worldX - gp.tileSize< gp.player.worldX + gp.player.screenX && 
				worldY + gp.tileSize>gp.player.worldY - gp.player.screenY &&
				worldY - gp.tileSize< gp.player.worldY +  gp.player.screenY) {
			
			switch(direction) {
			case "up" : 
				if(spriteNum ==1) {
				image = up1;
				}
				if(spriteNum==2) {
					image=up2;
				}
				break;
			case "down":
				if(spriteNum ==1) {
				image = down1;
				}
				if(spriteNum==2) {
					image=down2;
				}
				break;
			case "left":
				if(spriteNum ==1) {
					image = left1;
					}
				if(spriteNum==2) {
						image=left2;
					}
				break;
			case"right":
				if(spriteNum ==1) {
					image = right1;
					}
				if(spriteNum==2) {
						image=right2;
					}
				break;
			}
			
			if (invincible == true) {
				g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
				
			}
			if(dead == true) {
				deadAnimation(g2);
			}
				g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
				g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

		}
		
	}
	
	public void deadAnimation(Graphics2D g2) {
		
		deadCount++;
		
		
		
		if(deadCount <= 5) {
			changeAlpha(g2, 0f);
				}
		if(deadCount > 5 && deadCount <=10) {
			changeAlpha(g2, 1f);				}
		if(deadCount > 10 && deadCount <=15) {
			changeAlpha(g2, 0f);
				}
		if(deadCount > 15 && deadCount <=20) {
			changeAlpha(g2, 1f);				}
		if(deadCount > 20 && deadCount <=25) {
			changeAlpha(g2, 0f);
				}
		if(deadCount > 25 && deadCount <=30) {
			changeAlpha(g2, 1f);
				}
		if(deadCount > 30 && deadCount <=35) {
			changeAlpha(g2, 0f);				}
		if(deadCount> 35) {
			dead = false;
			alive = false;
		}
	}
	
	public void changeAlpha(Graphics2D g2, float alphaValue) {
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alphaValue));

	}
	
	public BufferedImage setup(String imagePath, int width, int height) {
		BufferedImage image=null;
		UtilityTool uTool = new UtilityTool();
		
		try {
			image = ImageIO.read(getClass().getResourceAsStream(imagePath));
			image = uTool.scaleImage(image, width, height);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return image;
	}

	
}



