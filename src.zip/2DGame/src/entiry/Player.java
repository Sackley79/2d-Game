package entiry;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;


import main.GamePanel;
import main.KeyHandler;
import main.OBJSetter;
import object.OBJ_Chest;
import object.OBJ_Potion;
import object.OBJ_Weapons;

public class Player extends Entiry {
	
	
	KeyHandler keyH;
	OBJSetter os;

	
	public final int screenX;
	public final int screenY;
	
	public ArrayList<Entiry> inventory = new ArrayList<>();
	public final int  invSize=20; 
	public Entiry potion = new OBJ_Potion(gp);
	public Entiry dagger = new OBJ_Weapons(gp, 0);
	public Entiry sword = new OBJ_Weapons(gp, 2);
	public Entiry axe = new OBJ_Weapons(gp, 3); 
	public Entiry spade = new OBJ_Weapons(gp, 1);
	
//	public int objIndex = gp.cChecker.checkObj(this, true);
	

	
		public Player(GamePanel gp, KeyHandler keyH) {
		super(gp);
		this.keyH=keyH;
		
		screenX = gp.screenWidth/2 - (gp.tileSize/2);
		screenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		solidArea = new Rectangle();
		solidArea.x = 8;
		solidArea.y=16;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		solidArea.width=32;
		solidArea.height=32;
		
		
		attackArea.width =40;
		attackArea.height = 45;
		
		setDefaultValue();
		getPlayerImage();
		getPlayerAttack();
		setItem();
		invincible = false;
		
	}
		
	public void resetItems() {
		inventory.clear();
		setItem();
	}
	
	public void setDefaultValue() {
		worldX = gp.tileSize *9;
		worldY = gp.tileSize *8;
		speed = 4;
		direction = "down";
		
		//player stat
		maxLife = 12;
		life = maxLife;
		currentWeapon =  dagger;
	}
	
	public void setItem() {
		inventory.add(currentWeapon);
		inventory.add(potion);
		inventory.add(potion);
	}
	
	public void getPlayerImage() {
			up1 = setup("/player/player_up_1.png", gp.tileSize,gp.tileSize);
			up2 = setup("/player/player_up_2.png", gp.tileSize,gp.tileSize);
			down1 = setup("/player/player_down_1.png", gp.tileSize,gp.tileSize);
			down2 = setup("/player/player_down_2.png", gp.tileSize,gp.tileSize);
			left1 = setup("/player/player_left_1.png", gp.tileSize,gp.tileSize);
			left2 = setup("/player/player_left_2.png", gp.tileSize,gp.tileSize);
			right1= setup("/player/player_right_1.png", gp.tileSize,gp.tileSize);
			right2 = setup("/player/player_right_2.png", gp.tileSize,gp.tileSize);
		
	}
	
	public void getPlayerAttack() {
		if(currentWeapon == dagger) { 
			attackUp = setup("/player/playerAttackUp-Dagger.png",gp.tileSize, gp.tileSize*2);
			attackDown = setup("/player/playerAttackDown-Dagger.png", gp.tileSize,gp.tileSize*2);
			attackLeft = setup("/player/playerAttackLeft-Dagger.png", gp.tileSize*2,gp.tileSize);
			attackRight = setup("/player/playerAttackRight-Dagger.png", gp.tileSize*2,gp.tileSize);
			} 
			if(currentWeapon == spade) {
			attackUp = setup("/player/playerAttackUp-Spade.png",gp.tileSize, gp.tileSize*2);
			attackDown = setup("/player/playerAttackDown-Spade.png", gp.tileSize,gp.tileSize*2);
			attackLeft = setup("/player/playerAttackLeft-Spade.png", gp.tileSize*2,gp.tileSize);
			attackRight = setup("/player/playerAttackRight-Spade.png", gp.tileSize*2,gp.tileSize);
			}
			if(currentWeapon == sword) {
			attackUp = setup("/player/playerAttackUp.png",gp.tileSize, gp.tileSize*2);
			attackDown = setup("/player/playerAttackDown.png", gp.tileSize,gp.tileSize*2);
			attackLeft = setup("/player/playerAttackLeft.png", gp.tileSize*2,gp.tileSize);
			attackRight = setup("/player/playerAttackRight.png", gp.tileSize*2,gp.tileSize);
			}
			if(currentWeapon == axe) {
			attackUp = setup("/player/playerAttackUp-Axe.png",gp.tileSize, gp.tileSize*2);
			attackDown = setup("/player/playerAttackDown-Axe.png", gp.tileSize,gp.tileSize*2);
			attackLeft = setup("/player/playerAttackLeft-Axe.png", gp.tileSize*2,gp.tileSize);
			attackRight = setup("/player/playerAttackRight-Axe.png", gp.tileSize*2,gp.tileSize);
			}

		
		
	}
	
	public void update() {
		
		
		healPlayer();
		
		if(attacking == true) {
			attack();
		
		}
		
		
		else if(keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed==true || keyH.rightPressed == true || keyH.spacePressed == true) {
			
		
		 if(keyH.upPressed == true){
			 direction="up";
	           
	            //playerY = playerY-playerSpeed. both are same thing
	        }
	        else if (keyH.downPressed == true){
	        	direction="down";
	            
	            
	        }
	        else if (keyH.leftPressed == true){
	        	direction = "left";
	           
	        }
	        else if(keyH.rightPressed == true){
	        	direction="right";
	         
	        }
		 //check player collision
		 collisionOn = false;
		 gp.cChecker.checkBG(this);
		 
		 //check obj collision
		 int objIndex = gp.cChecker.checkObj(this, true);
		 openChest(objIndex);
		 getChestInv(objIndex);
		 getChestIndex(objIndex);
		 
		 
		 

		 
		 //check npc collision
		 int npcIndex = gp.cChecker.checkEntiry(this, gp.npc);
		 interactNPC(npcIndex);
		 
		 //enemy collision
		 int enemyIndex = gp.cChecker.checkEntiry(this, gp.enemy);
		 contactEnemy(enemyIndex);
			 
		 
		 
		 //event 
		 gp.eHandle.checkEvent();
		 gp.keyH.enterPressed = false;
		 
		 if(collisionOn == false  && keyH.spacePressed == false) {
			 switch(direction) {
			 case"up":
				 worldY -= speed;
				break;
			case"down":
				worldY += speed;
				break;
			case "left":
				worldX -= speed;
				break;
			case"right":
				worldX += speed;
				break;
			 }
		 }
		 gp.keyH.spacePressed = false;
		 
		
		 spriteCounter++;
		 if(spriteCounter>10) {
			 if(spriteNum == 1) {
				 spriteNum=2;
			 }
			 else if(spriteNum == 2) {
				 spriteNum=1;
			 }
			 spriteCounter = 0;
		 }
		}
		else {
			standCounter++;
			if(spriteNum == 20) {
				spriteNum =1;
				standCounter = 0;
			}
		}
		
		if(invincible == true) {
			invincCount ++;
			if(invincCount > 60) {
				invincible = false;
				invincCount = 0;
			}
		}
		}
	
	


	
	public void interactNPC(int i) {
		
		
		if(i !=999) {
			gp.gameState = gp.dialougeState;
			gp.npc[i].speak();
		}
		
		if(gp.keyH.spacePressed == true) {
			attacking = true;
			gp.playsoundEffect(5);
		}
	}
	public void attack() {
		
			
		
		spriteCounter++;
		if(spriteCounter <=5) {
			spriteNum = 1;
		}if(spriteCounter>5 && spriteCounter<=20) {
			spriteNum= 2;
			
			int currentWorldX = worldX;
			int currentWorldY = worldY;
			int solidAreaWidth = solidArea.width;
			int solidAreaHeight = solidArea.height;
			
			switch(direction) {
			case"up": worldY -= attackArea.height; break;
			case"down": worldY += attackArea.height; break;
			case"left": worldX -= attackArea.width; break;
			case"right": worldX += attackArea.width; break;
			}
			solidArea.width = attackArea.width;
			solidArea.height = attackArea.height;
			
			int enemyIndex = gp.cChecker.checkEntiry(this, gp.enemy);
			
			worldX = currentWorldX;
			worldY = currentWorldY;
			solidArea.width = solidAreaWidth;
			solidArea.height = solidAreaHeight;
			damageEnemy(enemyIndex);
			
			}
		
		
		if(spriteCounter>20 ) {
			spriteNum= 1;
			spriteCounter = 0;
			attacking = false;
		}
		
		
	}
	
	public void openChest(int i) {
		if( i != 999 && gp.keyH.cPressed == true) {
			gp.gameState = gp.chestState;
			
		}
	}
	
	
	
	public void healPlayer() {
		for(int i=0; i<gp.player.inventory.size();i++) {
			if(gp.player.inventory.get(i) == gp.player.potion && gp.keyH.hPressed == true) {
				if(maxLife - life == 1) {
					inventory.remove(i);
					life += 1;
					gp.playsoundEffect(7);
					gp.keyH.hPressed = false;
				}
				if(life < maxLife) {
					inventory.remove(i);
					life += 2;
					gp.playsoundEffect(7);
					gp.keyH.hPressed = false;
				}
				
			}
		}
	}
	
	public void contactEnemy(int i) {
		if( i!= 999) {
			
			if(invincible == false) {
			life -= gp.enemy[i].damage;
			//gp.playsoundEffect(4);
			invincible = true;
			}
		}
	}
	
	
	
	public void damageEnemy(int i) {
		if(i != 999) {
			
			if(gp.enemy[i].invincible == false) {
				gp.playsoundEffect(6);
				gp.enemy[i].life -= currentWeapon.damage;
				gp.enemy[i].invincible = true;
				gp.enemy[i].enemyReact();
				
				
				
				if(gp.enemy[i].life <=0) {
					gp.enemy[i].dead = true;
					gp.enemyCount--;
					
				}
			}
		}
		
	}
	
	
	public int getChestIndex( int i) {
		if(i != 999) {
			return i;
		}
		else {
			return -1;
		}
	}
	
	
		
	
	public ArrayList<Entiry> getChestInv(int i) {
		if(i != 999) {
		 ArrayList<Entiry> chest = gp.obj[i].chestInv;
		 gp.chestIndex = i;
			return chest;
			
		}
		else {
			return null;
		}
		}
		


	
	
	public void switchEquip() {
		int itemIndex = gp.ui.getItemIndex();
		
		if(itemIndex < inventory.size()) {
			Entiry selectedItem = inventory.get(itemIndex);
			
			if(selectedItem != potion) {
				currentWeapon = selectedItem;
				getPlayerAttack();
			}
		}
	}
	
	
	public void draw(Graphics2D g2) {

		
		BufferedImage image = null;
		int tempScreenX = screenX;
		int tempScreenY = screenY;
		
		switch(direction) {
		case "up" : 
			if(attacking == false) {
			if(spriteNum ==1) {image = up1;}
			if(spriteNum==2) {image=up2;}
			}
			if(attacking == true) {
				tempScreenY = screenY-gp.tileSize;
				if(spriteNum ==1) {image = attackUp;}
				if(spriteNum==2) {image = attackUp;}
			}
			break;
		case "down":
			if(attacking == false) {
			if(spriteNum ==1) {image = down1;}
			if(spriteNum==2) {image=down2;}
			}
			if(attacking == true) {
				if(spriteNum ==1) {image = attackDown;}
				if(spriteNum==2) {image=attackDown;}
			}
			break;
		case "left":
			if(attacking == false) {
			if(spriteNum ==1) {image = left1;}
			if(spriteNum==2) {image=left2;}
			}
			if(attacking == true) {
				tempScreenX = screenX-gp.tileSize;
				if(spriteNum ==1) {image = attackLeft;}
				if(spriteNum==2) {image=attackLeft;}
			}
			break;
		case"right":
			if(attacking == false) {
			if(spriteNum ==1) {image = right1;}
			if(spriteNum==2) {image=right2;}
			}
			if(attacking == true) {
				if(spriteNum ==1) {image = attackRight;}
				if(spriteNum==2) {image=attackRight;}
			}
			break;
		
		}
		
//		int x = screenX; 
//		int y = screenY;
//		
//		if(screenX >worldX) {
//			x = worldX;
//		}
//		if(screenY > worldY) {
//			y = worldY;
//		}
//		int rightOffSet = gp.screenWidth-screenX;
//		if(rightOffSet > gp.worldWidth - worldX) {
//			x=gp.screenWidth-gp.worldWidth-worldX;
//		}
//		int downOffSet = gp.screenHeight-screenY;
//		if(downOffSet > gp.worldHeight - worldY) {
//			y=gp.screenHeight-gp.worldHeight - worldY;
//		}
//				
//				
		if (invincible == true) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
		}
		
		g2.drawImage(image, tempScreenX, tempScreenY , null);
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		

	}

}
