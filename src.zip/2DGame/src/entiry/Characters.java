package entiry;

import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;

public class Characters extends Entiry{

	

	public Characters(GamePanel gp) {
		super(gp);
		// TODO Auto-generated constructor stub
	}

	GamePanel gp;
	KeyHandler keyH;
	
	public void Character(GamePanel gp, KeyHandler keyH) {
		
		this.gp=gp;
		this.keyH=keyH;
		
	}
	
	public void getCharImage() {
		try {
			king = ImageIO.read(getClass().getResourceAsStream("/background/king.png"));
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
}

