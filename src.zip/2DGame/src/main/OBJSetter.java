package main;


import java.util.ArrayList;

import Enemy.Enemy_Dragon;
import Enemy.Enemy_Goblin;
import Enemy.Enemy_Skeleton;
import Enemy.Enemy_Snake;
import Enemy.Enemy_Spider;
import entiry.Entiry;
import entiry.NPC;
import object.OBJ_Chest;

public class OBJSetter {

	GamePanel gp ;
	public OBJ_Chest  c1, c2, c3, c4, c5, c6, c7;
	//,c2,  c3, c4,c5;
	public OBJSetter(GamePanel gp) {
		this.gp=gp;
		
	}
	
	public void setObj() {
		c1 = new OBJ_Chest(gp);
		gp.obj[0]= c1;
		gp.obj[0].worldX = 2 * gp.tileSize;
		gp.obj[0].worldY = 1 * gp.tileSize;
		c1.setInv(gp);
		
		 c2 = new OBJ_Chest(gp);
		gp.obj[1]= c2;
		gp.obj[1].worldX = 1 * gp.tileSize;
		gp.obj[1].worldY = 23 * gp.tileSize;
		c2.setInv(gp);
		
		c3 = new OBJ_Chest(gp);
		gp.obj[2]= c3;
		gp.obj[2].worldX = 5 * gp.tileSize;
		gp.obj[2].worldY = 43 * gp.tileSize;
		c3.setInv(gp);
		
		c4 = new OBJ_Chest(gp);
		gp.obj[3]= c4;
		gp.obj[3].worldX = 23 * gp.tileSize;
		gp.obj[3].worldY = 5 * gp.tileSize;
		c4.setInv(gp);
		
		c5 = new OBJ_Chest(gp);
		gp.obj[4]= c5;
		gp.obj[4].worldX = 41 * gp.tileSize;
		gp.obj[4].worldY = 6 * gp.tileSize;
		c5.setInv(gp);
		
		c6 = new OBJ_Chest(gp);
		gp.obj[5]= c6;
		gp.obj[5].worldX = 26 * gp.tileSize;
		gp.obj[5].worldY = 43 * gp.tileSize;
		c6.setInv(gp);
		
		c7 = new OBJ_Chest(gp);
		gp.obj[6]= c6;
		gp.obj[6].worldX = 26 * gp.tileSize;
		gp.obj[6].worldY = 27 * gp.tileSize;
		c7.setInv(gp);
		
		
		
		
		
	}
	public void setNPC() {
		gp.npc[0] = new NPC(gp);
		gp.npc[0].worldX = gp.tileSize*9;
		gp.npc[0].worldY = gp.tileSize*1;
	}
	
	public void setEnemy() {
		gp.enemy[0] = new Enemy_Spider(gp);
		gp.enemy[0].worldX = gp.tileSize*7;
		gp.enemy[0].worldY = gp.tileSize*18;
		
		gp.enemy[1] = new Enemy_Spider(gp);
		gp.enemy[1].worldX = gp.tileSize*6;
		gp.enemy[1].worldY = gp.tileSize*20;
		
		gp.enemy[2] = new Enemy_Spider(gp);
		gp.enemy[2].worldX = gp.tileSize*6;
		gp.enemy[2].worldY = gp.tileSize*23;
		
		gp.enemy[3] = new Enemy_Spider(gp);
		gp.enemy[3].worldX = gp.tileSize*6;
		gp.enemy[3].worldY = gp.tileSize*28;
		
		gp.enemy[4] = new Enemy_Spider(gp);
		gp.enemy[4].worldX = gp.tileSize*15;
		gp.enemy[4].worldY = gp.tileSize*23;
		
		gp.enemy[5] = new Enemy_Spider(gp);
		gp.enemy[5].worldX = gp.tileSize*16;
		gp.enemy[5].worldY = gp.tileSize*28;
		
		gp.enemy[6] = new Enemy_Spider(gp);
		gp.enemy[6].worldX = gp.tileSize*12;
		gp.enemy[6].worldY = gp.tileSize*15;
		
		gp.enemy[7] = new Enemy_Snake(gp);
		gp.enemy[7].worldX = gp.tileSize*12;
		gp.enemy[7].worldY = gp.tileSize*28;
		
		gp.enemy[8] = new Enemy_Snake(gp);
		gp.enemy[8].worldX = gp.tileSize*14;
		gp.enemy[8].worldY = gp.tileSize*24;
		
		gp.enemy[9] = new Enemy_Snake(gp);
		gp.enemy[9].worldX = gp.tileSize*7;
		gp.enemy[9].worldY = gp.tileSize*24;
		
		gp.enemy[10] = new Enemy_Snake(gp);
		gp.enemy[10].worldX = gp.tileSize*8;
		gp.enemy[10].worldY = gp.tileSize*25;
		
		gp.enemy[11] = new Enemy_Skeleton(gp);
		gp.enemy[11].worldX = gp.tileSize*23;
		gp.enemy[11].worldY = gp.tileSize*6;
		
		gp.enemy[12] = new Enemy_Skeleton(gp);
		gp.enemy[12].worldX = gp.tileSize*22;
		gp.enemy[12].worldY = gp.tileSize*6;
		
		gp.enemy[13] = new Enemy_Skeleton(gp);
		gp.enemy[13].worldX = gp.tileSize*24;
		gp.enemy[13].worldY = gp.tileSize*6;
		
		gp.enemy[14] = new Enemy_Skeleton(gp);
		gp.enemy[14].worldX = gp.tileSize*24;
		gp.enemy[14].worldY = gp.tileSize*32;
		
		gp.enemy[14] = new Enemy_Skeleton(gp);
		gp.enemy[14].worldX = gp.tileSize*25;
		gp.enemy[14].worldY = gp.tileSize*30;
		
		gp.enemy[15] = new Enemy_Skeleton(gp);
		gp.enemy[15].worldX = gp.tileSize*26;
		gp.enemy[15].worldY = gp.tileSize*30;
		
		gp.enemy[16] = new Enemy_Goblin(gp);
		gp.enemy[16].worldX = gp.tileSize*40;
		gp.enemy[16].worldY = gp.tileSize*37;
		
		gp.enemy[17] = new Enemy_Goblin(gp);
		gp.enemy[17].worldX = gp.tileSize*40;
		gp.enemy[17].worldY = gp.tileSize*38;
		
		gp.enemy[18] = new Enemy_Goblin(gp);
		gp.enemy[18].worldX = gp.tileSize*41;
		gp.enemy[18].worldY = gp.tileSize*37;
		
		gp.enemy[19] = new Enemy_Goblin(gp);
		gp.enemy[19].worldX = gp.tileSize*41;
		gp.enemy[19].worldY = gp.tileSize*38;
		
		gp.enemy[20] = new Enemy_Goblin(gp);
		gp.enemy[20].worldX = gp.tileSize*41;
		gp.enemy[20].worldY = gp.tileSize*33;
		
		gp.enemy[21] = new Enemy_Goblin(gp);
		gp.enemy[21].worldX = gp.tileSize*41;
		gp.enemy[21].worldY = gp.tileSize*36;
		
		gp.enemy[22] = new Enemy_Goblin(gp);
		gp.enemy[22].worldX = gp.tileSize*41;
		gp.enemy[22].worldY = gp.tileSize*35;
		
		gp.enemy[23] = new Enemy_Skeleton(gp);
		gp.enemy[23].worldX = gp.tileSize*41;
		gp.enemy[23].worldY = gp.tileSize*30;
		
		gp.enemy[24] = new Enemy_Skeleton(gp);
		gp.enemy[24].worldX = gp.tileSize*38;
		gp.enemy[24].worldY = gp.tileSize*35;
		
		gp.enemy[25] = new Enemy_Dragon(gp);
		gp.enemy[25].worldX = gp.tileSize*42;
		gp.enemy[25].worldY = gp.tileSize*36;
		
		
		
		
		
	}
}
