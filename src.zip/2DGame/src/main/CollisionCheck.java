package main;

import entiry.Entiry;

public class CollisionCheck {
	
	GamePanel gp;
	OBJSetter os;

	public CollisionCheck(GamePanel gp) {
		this.gp=gp;
	
		
	}
	
	public void checkBG(Entiry entiry) {
		
		
		int entiryLeftWolrdX = entiry.worldX + entiry.solidArea.x;
		int entiryRightWolrdX = entiry.worldX + entiry.solidArea.x + entiry.solidArea.width;
		int entiryTopWorldY = entiry.worldY + entiry.solidArea.y;
		int entiryBottomWorldY = entiry.worldY + entiry.solidArea.y + entiry.solidArea.height;
		
		int entiryLeftCol = entiryLeftWolrdX/gp.tileSize;
		int entiryRightCol = entiryRightWolrdX/gp.tileSize;
		int entiryBottomRow = entiryBottomWorldY/gp.tileSize;
		int entiryTopRow = entiryTopWorldY/gp.tileSize;
		
		int bgNum1, bgNum2;
		
		switch(entiry.direction) {
		case"up":
			entiryTopRow = (entiryTopWorldY - entiry.speed)/gp.tileSize;
			bgNum1 = gp.bgM.mapBGNum[entiryLeftCol][entiryTopRow];
			bgNum2 = gp.bgM.mapBGNum[entiryRightCol][entiryTopRow];
			if(gp.bgM.bg[bgNum1].collision == true || gp.bgM.bg[bgNum2].collision == true) {
				entiry.collisionOn = true;
			}
			break;
		case"down":
			entiryBottomRow = (entiryBottomWorldY + entiry.speed)/gp.tileSize;
			bgNum1 = gp.bgM.mapBGNum[entiryLeftCol][entiryBottomRow];
			bgNum2 = gp.bgM.mapBGNum[entiryRightCol][entiryBottomRow];
			if(gp.bgM.bg[bgNum1].collision == true || gp.bgM.bg[bgNum2].collision == true) {
				entiry.collisionOn = true;
			}
			break;
		case "left":
			entiryLeftCol = (entiryLeftWolrdX - entiry.speed)/gp.tileSize;
			bgNum1 = gp.bgM.mapBGNum[entiryLeftCol][entiryTopRow];
			bgNum2 = gp.bgM.mapBGNum[entiryLeftCol][entiryBottomRow];
			if(gp.bgM.bg[bgNum1].collision == true || gp.bgM.bg[bgNum2].collision == true) {
				entiry.collisionOn = true;
			}
			break;
		case"right":
			entiryRightCol = (entiryRightWolrdX - entiry.speed)/gp.tileSize;
			bgNum1 = gp.bgM.mapBGNum[entiryRightCol][entiryTopRow];
			bgNum2 = gp.bgM.mapBGNum[entiryRightCol][entiryBottomRow];
			if(gp.bgM.bg[bgNum1].collision == true || gp.bgM.bg[bgNum2].collision == true) {
			entiry.collisionOn = true;
			}
			break;
			
		}
	}
	
	public boolean checkPlayer(Entiry entiry) {
		boolean contactPlayer = false;
			
			
				//get entitys solid area
				entiry.solidArea.x = entiry.worldX + entiry.solidArea.x;
				entiry.solidArea.y = entiry.worldY + entiry.solidArea.y;
				
				
				//get objects solid position
				
				gp.player.solidArea.x = gp.player.worldX + gp.player.solidArea.x;
				gp.player.solidArea.y = gp.player.worldY + gp.player.solidArea.y;
						
				switch(entiry.direction) {
				case "up" :
					entiry.solidArea.y -= entiry.speed;
					break;
				case"down":
					entiry.solidArea.y += entiry.speed;
					break;
				case "left" :
					entiry.solidArea.x -= entiry.speed;
					break;
				case"right":
					entiry.solidArea.y += entiry.speed;
					break;
					}
				if(entiry.solidArea.intersects(gp.player.solidArea)) {
					
						entiry.collisionOn = true;
						contactPlayer = true;
					}
					entiry.solidArea.x = entiry.solidAreaDefaultX;
					entiry.solidArea.y = entiry.solidAreaDefaultY;
					gp.player.solidArea.x = gp.player.solidAreaDefaultX;
					gp.player.solidArea.y = gp.player.solidAreaDefaultY;
					
					return contactPlayer;
					}
				
			
		
	
	
	
	public int checkObj(Entiry entiry, boolean player) {
		int index=999;
		
		for (int i=0; i<gp.obj.length; i++){
			
			if(gp.obj[i] !=null) {
				//get entitys solid area
				entiry.solidArea.x = entiry.worldX + entiry.solidArea.x;
				entiry.solidArea.y = entiry.worldY + entiry.solidArea.y;
				
				
				//get objects solid position
				
				gp.obj[i].solidArea.x = gp.obj[i].worldX + gp.obj[i].solidArea.x;
				gp.obj[i].solidArea.y = gp.obj[i].worldY + gp.obj[i].solidArea.y;
						
				switch(entiry.direction) {
				case "up" :
					entiry.solidArea.y -= entiry.speed;
					break;
				case"down":
					entiry.solidArea.y += entiry.speed;
					break;
				case "left" :
					entiry.solidArea.x -= entiry.speed;
					break;
				case"right":
					entiry.solidArea.y += entiry.speed;
					break;
					}
				if(entiry.solidArea.intersects(gp.obj[i].solidArea)) {
					if(gp.obj[i].Collision == true) {
						entiry.collisionOn = true;
						
						
					}
					if (player == true) {
						index = i;
					}
				}
				
			
			entiry.solidArea.x = entiry.solidAreaDefaultX;
			entiry.solidArea.y = entiry.solidAreaDefaultY;
			gp.obj[i].solidArea.x = gp.obj[i].solidAreaDefaultX;
			gp.obj[i].solidArea.y = gp.obj[i].solidAreaDefaultY;
			}
		}
		
		return index;
	}
	
	
	//check collision with npc
	public int checkEntiry(Entiry entiry, Entiry[] target) {
		int index=999;
		
		for (int i=0; i<target.length; i++){
			
			if(target[i] !=null) {
				//get entitys solid area
				entiry.solidArea.x = entiry.worldX + entiry.solidArea.x;
				entiry.solidArea.y = entiry.worldY + entiry.solidArea.y;
				
				
				//get objects solid position
				
				target[i].solidArea.x = target[i].worldX + target[i].solidArea.x;
				target[i].solidArea.y = target[i].worldY + target[i].solidArea.y;
						
				switch(entiry.direction) {
				case "up" :
					entiry.solidArea.y -= entiry.speed;
					break;
				case"down":
					entiry.solidArea.y += entiry.speed;
					break;
				case "left" :
					entiry.solidArea.x -= entiry.speed;
					break;
				case"right":
					entiry.solidArea.y += entiry.speed;		
					break;
					}
				if(entiry.solidArea.intersects(target[i].solidArea)) {
					if(target[i] != entiry) {
						
					entiry.collisionOn = true;
					index = i;
						}
				}
				
			
			entiry.solidArea.x = entiry.solidAreaDefaultX;
			entiry.solidArea.y = entiry.solidAreaDefaultY;
			target[i].solidArea.x = target[i].solidAreaDefaultX;
			target[i].solidArea.y = target[i].solidAreaDefaultY;
			}
		}
		
		return index;
	}
	

}
