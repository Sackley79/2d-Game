package main;

import javax.swing.JPanel;

import background.BackgroundManage;
import entiry.Entiry;
import entiry.Player;
import object.OBJ_Chest;

import java.awt.Dimension;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class GamePanel extends JPanel implements Runnable
{
    //Screen settings
    final int originalTileSize = 16; // 16x16 tile
    final int scale = 4;
    
    public final int tileSize = originalTileSize * scale;//48x48
    public final int maxScreenCol = 16;
    public final int maxScreenRow = 12;
    public final int screenWidth = tileSize * maxScreenCol; //768
    public final int screenHeight = tileSize * maxScreenRow;  // 576
    
    
    //world settings
    public final int maxWorldCol = 50;
    public final int maxWorldRow= 50;
//    public final int worldWidth = tileSize * maxWorldCol;
//    public final int worldHeight = tileSize * maxWorldRow;
    
    //FPS
    int FPS = 60;
    
    BackgroundManage bgM = new BackgroundManage(this);
    public KeyHandler keyH = new KeyHandler(this);
    public EventHandler eHandle = new EventHandler(this);
    Thread gameThread;
    public CollisionCheck cChecker = new CollisionCheck (this);
    public OBJSetter setter = new OBJSetter(this);
    Sound sound = new Sound();
    public UI ui = new UI(this);
    public Player player = new Player (this,keyH);
    public Entiry obj[] = new Entiry[7];
    public Entiry npc[] = new Entiry[1];
    public Entiry enemy[] = new Entiry[26];
    public int enemyCount = enemy.length;
    ArrayList<Entiry> entiryList = new ArrayList<>();
    
    public ArrayList<Entiry> chestNum = new ArrayList<>();
//    public ArrayList<Entiry> chestInv = new ArrayList<>();
//    public ArrayList<Entiry> chestInv1 = new ArrayList<>();
//    public ArrayList<Entiry> chestInv2 = new ArrayList<>();
//    public ArrayList<Entiry> chestInv3 = new ArrayList<>();
//    public ArrayList<Entiry> chestInv4 = new ArrayList<>();
//    public ArrayList<Entiry> chestInv5 = new ArrayList<>();
//    public ArrayList<Entiry> chestInv6 = new ArrayList<>();
//    
   
    public int chestIndex = 0;
    //game state
    public int gameState;
    public final int titleState = 0;
    public final int playState=1;
    public final int pauseState=2;
    public final int dialougeState = 3;
    public final int chestState = 4;
    public final int deathState = 5;
    public final int invState = 6;
    public final int howState = 7;
    public final int endState = 8;
    
    
    
    
    

    public GamePanel(){
       this.setPreferredSize(new Dimension(screenWidth,screenHeight));
       this.setBackground(Color.black);
       this.setDoubleBuffered(true);
       this.addKeyListener(keyH);
       this.setFocusable(true);
       
       
       
    }
    
   
    public void setUpGame() {
    	setter.setObj();
    	setter.setNPC();
    	setter.setEnemy();
    	
    	playMusic(0);
    	
    	
    	
    	gameState = titleState;
    }
    
    public void startGameThread(){
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    @Override
    public void run(){
        
        double drawInterval = 1000000000/FPS;
        
        double nextDrawTime = System.nanoTime() + drawInterval;
        
        while(gameThread != null){
            
            
            
            //System.out.println("The game loop is running");
            //what happenes in this loop
            // 1 update information such as char positions
            update();
            // 2 draw the screen with the updated information
            repaint();// how to call paintComponent method
            
            
             
            try{
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime/1000000;
                
                if(remainingTime<0){
                    remainingTime=0;
                }
                
                Thread.sleep((long) remainingTime);//has to accept in milliSec
                
                nextDrawTime += drawInterval;
            }
            
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        
    }
    
//    public void playMusic() {
//    	if(gameState == deathState) {
//    		stopMusic(0);
//    		playMusic(8);
//    	}
//    	else {
//    		
//    		playMusic(0);
//    	}
//    }
    
    public void update(){
    	if(player.life <=0) {
    		gameState = deathState;
    	}
        if(gameState == playState) {
        player.update();
        for(int i=0; i< enemy.length; i++) {
        	if(enemy[i] != null) {
        		if(enemy[i].alive == true && enemy[i].dead==false) {
        		enemy[i].update();
        	}
        		if(enemy[i].alive == false) {
            		enemy[i] = null;
            	}
        }
        
        }
        }
        if(gameState==pauseState) {
        	
        }
        if(enemyCount == 0) {
        	gameState = endState;
        }
       
    }
    
    public void paintComponent(Graphics g){
        
        super.paintComponent(g);
        
        Graphics2D g2 = (Graphics2D)g;
        
        //draw title
        if(gameState == titleState) {
        	ui.draw(g2);
        }
        
        else {
        	//draw tiles
            bgM.draw(g2);
            
            
            //add entirys to list
            entiryList.add(player);
            
            for(int i=0; i<npc.length;i++) {
            	if(npc[i] != null) {
            		entiryList.add(npc[i]);
            	}
            }
            
            for(int i=0; i<enemy.length;i++) {
            	if(enemy[i] != null) {
            		entiryList.add(enemy[i]);
            	}
            }
            
            for(int i=0; i<obj.length; i++) {
            	if(obj[i] != null) {
            		entiryList.add(obj[i]);
            	}
            }
        //comparator method    
          Collections.sort(entiryList , new Comparator<Entiry>(){

			@Override
			public int compare(Entiry y1, Entiry y2) {
				int result = Integer.compare(y1.worldY, y2.worldY);
				return result;
			}
        	  
          });
          
          //draw entirys
          for(int i=0; i<entiryList.size();i++) {
        	  entiryList.get(i).draw(g2);
          }
          
          entiryList.clear();
          
          
          //  g2.dispose();
            ui.draw(g2);
        }
        
     
    }
    
//    public void setChestInv(OBJ_Chest chest,ArrayList<Entiry> c, GamePanel gp ) {//ArrayList<Entiry> chestInv ) {
//    	List<Entiry> items = new ArrayList<>();
//    	items.add(player.axe);
//    	items.add(player.dagger);
//    	items.add(player.spade);
//    	items.add(player.sword);
//    	items.add(player.potion);
//    	items.add(player.potion);
//    	items.add(player.potion);
//    	items.add(player.potion);
//    	items.add(player.potion);
//    	items.add(player.potion);
//    	
//    	items = items.stream().collect(Collectors.toList());
//    			Collections.shuffle(items);
//    	
//    	items.stream().limit(3);
//    	for(int i=0; i<3;i++) {
//    		chest.setInv(c,items.get(i));
//    	}
//    	
//   		.forEach();
//    }
    

    
    public void playMusic(int i) {
    	sound.setFile(i);
    	sound.play();
    	sound.loop();
    	
    }
    public void playsoundEffect(int i) {
    	sound.setFile(i);
    	sound.play();
    	
    	
    }
    
    public void stopMusic() {
    	
    	sound.stop();
    }
    
   
    
    
    
}

