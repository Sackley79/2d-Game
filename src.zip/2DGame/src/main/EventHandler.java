package main;

import java.awt.Rectangle;

import entiry.Entiry;

public class EventHandler {

	GamePanel gp;
	EventRect eventRec[][];
	
	int prevEventX, prevEventY;
	boolean canTouchEvent = true;
	
	public EventHandler(GamePanel gp) {
		this.gp = gp;
		eventRec = new EventRect[gp.maxWorldCol][gp.maxWorldRow];
		
		int col=0; 
		int row = 0;
		while(col<gp.maxWorldCol && row<gp.maxWorldRow) {
			eventRec[col][row] = new EventRect();
			eventRec[col][row].x = 23;
			eventRec[col][row].y = 23;
			eventRec[col][row].width = 4;
			eventRec[col][row].height = 4;
			eventRec[col][row].eventRecDefaultX = eventRec[col][row].x;
			eventRec[col][row].eventRecDefaultY = eventRec[col][row].y;
			
			col++;
			if(col == gp.maxWorldCol) {
				col=0;
				row++;
			}
		}
		
		
		
	}
	
	public void checkEvent() {
		//check player move from tile
		int xDistance = Math.abs(gp.player.worldX - prevEventX);
		int yDistance = Math.abs(gp.player.worldY - prevEventY);
		int distance = Math.max(xDistance, yDistance);
		if(distance > gp.tileSize) {
			canTouchEvent = true;
		}
		
		if(canTouchEvent == true) {
			if(hit(10,10,"any") == true) {
				flashBang(10, 10,gp.dialougeState);
			}
			if(hit(39,37,"any") == true) {
				flashBang(39,37,gp.dialougeState);
			}
			if(hit(36,13,"any") == true) {
				flashBang(36,13,gp.dialougeState);
			}
			if(hit(21,23,"any") == true) {
				flashBang(21,23,gp.dialougeState);
			}
			
			
//			if(hit(37,33,"any") == true){// || hit(38,33,"any") == true || hit(39,33,"any") == true || hit(40,33,"any") == true) {
//				finalRoom(37,33,gp.dialougeState);
//			}
			
		}
		
		
		if(hit(34,9,"right")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(34,8,"right")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(34,10,"right")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(35,11,"up")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(36,11,"up")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(37,11,"up")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(38,11,"up")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(39,9,"left")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(39,8,"left")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(39,10,"left")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(35,7,"down")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(36,7,"down")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(37,7,"down")==true) {
			healingPool(gp.dialougeState);
		}
		if(hit(38,7,"down")==true) {
			healingPool(gp.dialougeState);
		}
	}
	
	public boolean hit(int col, int row, String reqDirection) {
		
		boolean hit = false;
		
		gp.player.solidArea.x = gp.player.worldX + gp.player.solidArea.x;
		gp.player.solidArea.y = gp.player.worldY + gp.player.solidArea.y;
		eventRec[col][row].x = col*gp.tileSize + eventRec[col][row].x;
		eventRec[col][row].y = row*gp.tileSize + eventRec[col][row].y;
		
		if(gp.player.solidArea.intersects(eventRec[col][row]) && eventRec[col][row].eventDone == false) {
			if(gp.player.direction.contentEquals(reqDirection) || reqDirection.contentEquals(("any"))) {
				hit = true;
				
				prevEventX = gp.player.worldX;
				prevEventY = gp.player.worldY;
			}
		}
		
		gp.player.solidArea.x = gp.player.solidAreaDefaultX;
		gp.player.solidArea.y = gp.player.solidAreaDefaultY;
		
		eventRec[col][row].x = eventRec[col][row].eventRecDefaultX;
		eventRec[col][row].y = eventRec[col][row].eventRecDefaultY;
		
		
		return hit;
		
	}
	
	public void flashBang(int col,int row,int gameState) {
		gp.gameState = gameState;
		gp.ui.currentDialouge = "Think fast chucklenuts";
		gp.player.life -= 1;
		gp.playsoundEffect(3);
//		eventRec[col][row].eventDone=true;
		canTouchEvent = false;
		
		
	}
	
	public void healingPool(int gameState) {
		if(gp.keyH.enterPressed == true) {
			gp.gameState = gameState;
			gp.ui.currentDialouge = "You have sipped from the pool of \nblue mountain dew";
			gp.player.life = gp.player.maxLife;
		}
		
		
		
	}
	
	public void finalRoom(int col,int row,int gameState) {
		
		gp.gameState = gameState;
		gp.ui.currentDialouge = "Slay all the goblins";
		gp.stopMusic();
		gp.playMusic(1);
		eventRec[col][row].eventDone=true;
		canTouchEvent = false;
	}
	
//	public void finalDone(int gameState) {
//		int gobCount =0;
//		for(int i=0; i<gp.enemy.length; i++) {
//			if(gp.enemy[i] == Entiry.Enemy_Goblin) {
//		}
//		
//	}
}
