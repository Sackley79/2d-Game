package main;


import java.awt.event.KeyListener;

import entiry.Entiry;
import entiry.NPC;
import object.OBJ_Chest;

import java.awt.event.KeyEvent;

public class KeyHandler implements KeyListener 
{
    GamePanel gp;
    OBJSetter os;
    Entiry entiry;
    
    NPC npc;
    
    public boolean upPressed,downPressed, leftPressed, rightPressed, enterPressed, spacePressed, hPressed, cPressed;
    
    boolean checkDrawTime = false;

	
    
    public KeyHandler(GamePanel gp) {
    	this.gp=gp;
    	
    }
    
    @Override 
    public void keyTyped(KeyEvent e){
        //not used
        }
    
    @Override 
    public void keyPressed(KeyEvent e){
    	 int code = e.getKeyCode();//returns the number associated with the key pressed

    	 //title state
    	 if(gp.gameState == gp.titleState) {
    		 titleState(code);
    	 }
    	 
    	 //playstate
    	 else if(gp.gameState == gp.playState) {
    		 
    		playState(code);
    	}
    	 else if(gp.gameState == gp.howState) {
    		 howState(code);
    	 }
         //pause state
         else if(gp.gameState == gp.pauseState) {
        	 pauseState(code);
         }
         else  if(gp.gameState == gp.deathState) {
        	
        	 deadState(code);
         }
        	   
         else if(gp.gameState == gp.invState) {
        	 invState(code);
        	   }
         
         //dialouge state
         
         else if(gp.gameState == gp.dialougeState ) {
        	dialougeState(code);
        		
         }
    	
    	
         else if(gp.gameState == gp.chestState ) {
	  		chestState(code);
         }
    	 
         else if(gp.gameState == gp.endState) {
        	 endState(code);
         }
    }
  
    
 	
     public void titleState(int code) {
    	//gp.stopMusic();
    	
 	        if (code == KeyEvent.VK_W){
 	           gp.ui.commNum--;
 	           if(gp.ui.commNum < 0) {
 	        	   gp.ui.commNum = 1;
 	           }
 	        }
 	        if (code == KeyEvent.VK_S){
  	           gp.ui.commNum++;
  	          if(gp.ui.commNum >1) {
	        	   gp.ui.commNum = 0;
	           }
 	        }
 	        if(code == KeyEvent.VK_ENTER) {
 	        	if (gp.ui.commNum == 0) {
 	        		gp.gameState = gp.howState;
 	        	}
// 	        	if (gp.ui.commNum == 1) {
// 	        		//load
// 	        	}
 	        	if (gp.ui.commNum == 1) {
 	        		System.exit(1);
 	        	}
 	        	
 	        }     
 	 }
     public void howState(int code) {
    	 if(code == KeyEvent.VK_ENTER) {
	        	if (gp.ui.commNum == 0) {
	        		gp.gameState = gp.playState;
	        	}
    	 }
     }
     public void deadState(int code) {
    	
    	    if (code == KeyEvent.VK_W){
  	           gp.ui.commNum--;
  	           if(gp.ui.commNum < 0) {
  	        	   gp.ui.commNum = 1;
  	           }
  	        }
  	        if (code == KeyEvent.VK_S){
   	           gp.ui.commNum++;
   	          if(gp.ui.commNum >1) {
 	        	   gp.ui.commNum = 0;
 	           }
  	        }
  	        if(code == KeyEvent.VK_ENTER) {
  	        	if (gp.ui.commNum == 0) {
  	        		gp.gameState = gp.titleState;
  	        		gp.player.setDefaultValue();
  	        		gp.player.resetItems();
  	        		gp.setter.setEnemy();
  	        		gp.setter.setObj();
  	        		gp.enemyCount = gp.enemy.length;
  	        	
  	        	}

  	        	if (gp.ui.commNum == 1) {
  	        		System.exit(1);
  	        	}
     }
     }
     
     public void endState(int code) {
     	
 	    if (code == KeyEvent.VK_W){
	           gp.ui.commNum--;
	           if(gp.ui.commNum < 0) {
	        	   gp.ui.commNum = 1;
	           }
	        }
	        if (code == KeyEvent.VK_S){
	           gp.ui.commNum++;
	          if(gp.ui.commNum >1) {
	        	   gp.ui.commNum = 0;
	           }
	        }
	        if(code == KeyEvent.VK_ENTER) {
	        	if (gp.ui.commNum == 0) {
	        		gp.gameState = gp.titleState;
	        		gp.player.setDefaultValue();
	        		gp.player.resetItems();
	        		gp.setter.setEnemy();
	        		gp.setter.setObj();
	        		gp.enemyCount = gp.enemy.length;
	        	
	        	}

	        	if (gp.ui.commNum == 1) {
	        		System.exit(1);
	        	}
  }
  }
     
     
     public void playState(int code) {
    	 
         if (code == KeyEvent.VK_W){
             upPressed = true;
         }
         
         if (code == KeyEvent.VK_A){
             leftPressed = true;
         }
         
         if (code == KeyEvent.VK_S){
             downPressed = true;
         }
         
          if (code == KeyEvent.VK_D){
             rightPressed = true;
         }
          if (code == KeyEvent.VK_H){
              hPressed = true;
          }
          if (code == KeyEvent.VK_C){
              cPressed = true;
          }
          if (code == KeyEvent.VK_I){
              gp.gameState = gp.invState;
          }
          
          if (code == KeyEvent.VK_ENTER){
              enterPressed = true;
          }
          if(code == KeyEvent.VK_SPACE) {
         	 spacePressed = true;
          }
          if (code == KeyEvent.VK_P) {
         	 gp.gameState = gp.pauseState;
         	
          }
     }
     
     
     public void pauseState(int code) {
  	   if (code == KeyEvent.VK_P) {
  		 gp.gameState = gp.playState;
     }
     }
     
     public void dialougeState(int code) {
       	
    	 if(code == KeyEvent.VK_ENTER) {
    		
    		 gp.gameState = gp.playState;
    		
    		
    	 }
     }
     
     public void chestState(int code) {
    	  if (code == KeyEvent.VK_C){
              gp.gameState = gp.playState;
      }
		  
		   if(code == KeyEvent.VK_A) {
			   if(gp.ui.slotCol != 0) { gp.ui.slotCol--; }
		   }
		   
		   if(code == KeyEvent.VK_D) {
			   if(gp.ui.slotCol != 2) {gp.ui.slotCol++; }
		   }
		   if(code == KeyEvent.VK_ENTER) {
			    //remove from chest and add to inventory
			    if(gp.player.getChestInv(gp.chestIndex) != null) {
				   	gp.player.inventory.add(gp.player.getChestInv(gp.chestIndex).get(gp.ui.slotCol));
				   	gp.player.getChestInv(gp.chestIndex).remove(gp.ui.slotCol);
			    }
		   }
			   	
			   
		   }
     
     
     
     public void invState(int code) {
    	  if (code == KeyEvent.VK_I){
              gp.gameState = gp.playState;
      }
		   if(code == KeyEvent.VK_W) {
			   if(gp.ui.slotRow != 0) { gp.ui.slotRow--; }
		   }
		   if(code == KeyEvent.VK_A) {
			   if(gp.ui.slotCol != 0) { gp.ui.slotCol--; }
		   }
		   if(code == KeyEvent.VK_S) {
			   if(gp.ui.slotRow != 3) {gp.ui.slotRow++; }
		   }
		   if(code == KeyEvent.VK_D) {
			   if(gp.ui.slotCol != 4) {gp.ui.slotCol++; }
		   }
		   if(code == KeyEvent.VK_ENTER ) {
			   gp.player.switchEquip();
    
     		}
     }
        
    @Override 
    public void keyReleased(KeyEvent e){
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_W){
            upPressed = false;
        }
        
        if (code == KeyEvent.VK_A){
            leftPressed = false;
        }
        
        if (code == KeyEvent.VK_S){
            downPressed = false;
        }
        if (code == KeyEvent.VK_H){
            hPressed = false;
        }
        if (code == KeyEvent.VK_C){
            cPressed = false;
        }
        
         if (code == KeyEvent.VK_D){
            rightPressed = false;
        }
         if (code == KeyEvent.VK_ENTER){
             enterPressed = false;
         }
         if(code == KeyEvent.VK_SPACE) {
        	 spacePressed = false;
         }
        
    }
    
}



