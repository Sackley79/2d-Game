package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import entiry.Entiry;
import object.OBJ_Chest;
import object.OBJ_Heart;
import object.OBJ_Potion;


public class UI {

	GamePanel gp;
	Graphics2D g2;
	Entiry entiry;
	OBJSetter os;
	OBJ_Chest chest;
	Font arial_40, arial_80B;
	BufferedImage Full_Heart, Half_Heart, Empty_Heart, Potion; 
	public boolean messageOn = false;
	public String message= " ";
	int messageCount = 0;
	public String currentDialouge = "";
	public int commNum = 0;
	
	public int invIndex = 0;
	public int slotCol = 0;
	public int slotRow = 0;
	
	
	
	public UI(GamePanel gp) {
		this.gp=gp;
		
		
		arial_40 = new Font("Arial", Font.PLAIN, 40);
		arial_80B = new Font("Arial", Font.BOLD, 80);
		
		
		//create hud
		Entiry heart =new OBJ_Heart(gp);
		Full_Heart = heart.image;
		Half_Heart = heart.image2;
		Empty_Heart = heart.image3;
		Entiry potion = new OBJ_Potion(gp);
		Potion = potion.image;
		
		
		
	}
	public void showMessage(String text) {
		message =text;
		messageOn=true;
	}
	
	public void draw(Graphics2D g2) {
		this.g2=g2;
		
		g2.setFont(arial_40);
		g2.setColor(Color.white);
		
		if(gp.gameState == gp.titleState) {
			drawTitle();
		}
		if(gp.gameState == gp.howState) {
			drawHow();
		}
		if(gp.gameState == gp.deathState) {
			//gp.playMusic(8);
			drawDeathTitle();
		}
		
		if(gp.gameState == gp.playState) {
			drawPlayerHeart();
			drawPotionCount();
		}
		if(gp.gameState == gp.pauseState) {
			drawPause();
		}
		if(gp.gameState == gp.dialougeState) {
			
			drawDialouge();
			
		}
		if(gp.gameState == gp.endState) {
			drawEnd();
		}
		if(gp.gameState==gp.chestState) {
			gp.player.getChestIndex(gp.chestIndex);
			drawChestOpened(gp.player.getChestInv(gp.chestIndex));
			
		}
		if(gp.gameState == gp.invState) {
			drawInv();
		}
		
	}
	
	public void drawTitle() {
		//title name
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 85F));
		String title = "Pixel Journey";//game name
		int x = drawXCentered(title);
		int y = gp.tileSize *4;
		g2.setColor(Color.white);
		g2.drawString(title, x, y);
		
		//menu
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 40F));
		String text = "NEW GAME";
		x = drawXCentered(text);
		y += gp.tileSize *4;
		g2.drawString(text, x, y);
		if(commNum == 0) {
			g2.drawString(">", x-gp.tileSize, y);
			g2.drawString("<", x+gp.tileSize*4, y);
		}
		
//		 text = "LOAD GAME";
//		x = drawXCentered(text);
//		y += gp.tileSize;
//		g2.drawString(text, x, y);
//		if(commNum == 1) {
//			g2.drawString(">", x-gp.tileSize, y);
//			g2.drawString("<", x+gp.tileSize*4, y);
//		}
		
		 text = "EXIT";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		if(commNum == 1) {
			g2.drawString(">", x-gp.tileSize, y);
			g2.drawString("<", x+gp.tileSize*2, y);
		}
		
	}
	
	public void drawHow() {

		g2.setColor(Color.black);
		g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 85F));
		String title = "Controls";//game name
		int x = drawXCentered(title);
		int y = gp.tileSize *2;
		g2.setColor(Color.white);
		g2.drawString(title, x, y);
		
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 40F));
		String text = "D = move left";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "S = move Down";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "W = move up";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "A = move right";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "I = open/close Inventory";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "C =open/close chest ";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "Space = Attack";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "H = Heal";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		 text = "Enter = interact";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
	}
	
	public void drawDeathTitle() {
		//title name
		//gp.stopMusic();
		g2.setColor(Color.black);
		g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 85F));
		String title = "Sorry you died";//game name
		int x = drawXCentered(title);
		int y = gp.tileSize *4;
		g2.setColor(Color.white);
		g2.drawString(title, x, y);
		
		//menu
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 40F));
		String text = "BACK TO TITLE";
		x = drawXCentered(text);
		y += gp.tileSize *4;
		g2.drawString(text, x, y);
		if(commNum == 0) {
			g2.drawString(">", x-gp.tileSize, y);
			g2.drawString("<", x+gp.tileSize*5, y);
		}
		
//		 text = "LOAD GAME";
//		x = drawXCentered(text);
//		y += gp.tileSize;
//		g2.drawString(text, x, y);
//		if(commNum == 1) {
//			g2.drawString(">", x-gp.tileSize, y);
//			g2.drawString("<", x+gp.tileSize*4, y);
//		}
		
		 text = "EXIT";
		x = drawXCentered(text);
		y += gp.tileSize;
		g2.drawString(text, x, y);
		if(commNum == 1) {
			g2.drawString(">", x-gp.tileSize, y);
			g2.drawString("<", x+gp.tileSize*2, y);
		}
		
	}
	
	
	public void drawPlayerHeart() {
		
		int x = gp.tileSize/2;
		int y = gp.tileSize/2;
		int i=0;
		
		//max life
		while (i<gp.player.maxLife/2) {
			g2.drawImage(Empty_Heart, x, y, gp.tileSize, gp.tileSize, null);
			i++;
			x += gp.tileSize;
		}
		
		//reset
		 x = gp.tileSize/2;
		 y = gp.tileSize/2;
		 i=0;
		 
		 //draw current life 
		 while(i<gp.player.life) {
			 g2.drawImage(Half_Heart, x, y, gp.tileSize, gp.tileSize, null);
			 i++;
			 if(i<gp.player.life) {
				 g2.drawImage(Full_Heart, x, y, gp.tileSize, gp.tileSize, null);
			 }
			 i++;
			 x += gp.tileSize;
		 }
		
	}
	
	public void drawPotionCount() {
		int x = gp.tileSize/2;
		int y = gp.tileSize*2;
		int potionCount =0;
		
		for(int i=0; i<gp.player.inventory.size();i++) {
			if(gp.player.inventory.get(i) == gp.player.potion) {
				potionCount ++;
			}
		}
		
		g2.drawImage(Potion, x, y, gp.tileSize, gp.tileSize, null);
		g2.drawString("X " + potionCount, 100, gp.tileSize*3);
		
		
	}
	
	public void drawDialouge() {
		//window
		int x = gp.tileSize*2;
		int y = gp.tileSize/2;
		int width = gp.screenWidth - (gp.tileSize*4);
		int height = gp.tileSize *4 ;
		
		drawWindow(x,y,width,height);
		g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 32f));
		x += gp.tileSize;
		y += gp.tileSize;
		
		for(String line : currentDialouge.split("\n")){
			g2.drawString(line, x, y);
			y += 40;
		}
		
	}
	
	

	
	public void drawChestOpened(ArrayList<Entiry> arrayList) {
		
		int x = gp.tileSize*9;
		int y = gp.tileSize/2;
		int width =  gp.tileSize*4;
		int height = gp.tileSize *2 ;
		drawWindow(x,y,width,height);
		
		final int slotXStart = x +20 ;
		final int slotYStart = y +20;
		int slotX = slotXStart;
		int slotY = slotYStart;
		
	
		
		for(int i=0; i< arrayList.size();i++) {
			g2.drawImage(arrayList.get(i).image, slotX, slotY, null);
			slotX += gp.tileSize;
		
		}

		
			
			int cursorX = slotXStart + (gp.tileSize * slotCol);
			int cursorY = slotYStart + (gp.tileSize * slotRow);
			int cursorWidth = gp.tileSize;
			int cursorHeight = gp.tileSize;
			
			g2.setColor(Color.white);
			g2.drawRoundRect(cursorX, cursorY, cursorWidth, cursorHeight, 10, 10);
	}


		


		
		
	
	
	
	
	public void drawWindow(int x, int y, int width, int height) {
		Color c = new Color(0,0,0);
		g2.setColor(c);
		g2.fillRoundRect(x, y, width, height, 35, 35);
		
		c = new Color(255,255,255);
		g2.setColor(c);
		g2.setStroke(new BasicStroke(5));
		g2.drawRoundRect(x+5, y+5, width-10, height-10, 25, 25);
	}
	
	public void drawPause() {

		g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 80));
		String text = "PAUSED";
		int drawX = drawXCentered(text);
		int drawY = gp.screenHeight/2;
		g2.drawString(text, drawX, drawY);
	}
	
	public void drawEnd() {
			//gp.stopMusic();
			g2.setColor(Color.black);
			g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
			g2.setFont(g2.getFont().deriveFont(Font.BOLD, 85F));
			String title = "YOU WIN";//game name
			int x = drawXCentered(title);
			int y = gp.tileSize *4;
			g2.setColor(Color.white);
			g2.drawString(title, x, y);
			
			//menu
			g2.setFont(g2.getFont().deriveFont(Font.BOLD, 40F));
			String text = "BACK TO TITLE";
			x = drawXCentered(text);
			y += gp.tileSize *4;
			g2.drawString(text, x, y);
			if(commNum == 0) {
				g2.drawString(">", x-gp.tileSize, y);
				g2.drawString("<", x+gp.tileSize*5, y);
			}
			
			 text = "EXIT";
			x = drawXCentered(text);
			y += gp.tileSize;
			g2.drawString(text, x, y);
			if(commNum == 1) {
				g2.drawString(">", x-gp.tileSize, y);
				g2.drawString("<", x+gp.tileSize*2, y);
			}
	}

	public void drawInv() {
		int x = gp.tileSize*9;
		int y = gp.tileSize/2;
		int width =  gp.tileSize*6;
		int height = gp.tileSize *5 ;
		currentEquip();
		drawWindow(x,y,width,height);
		
		final int slotXStart = x +20 ;
		final int slotYStart = y +20;
		int slotX = slotXStart;
		int slotY = slotYStart;
		
		for(int i=0; i<gp.player.inventory.size();i++) {
			if(gp.player.inventory.get(i) == gp.player.currentWeapon) {
				g2.setColor(Color.ORANGE);
				g2.fillRoundRect(slotX, slotY, gp.tileSize, gp.tileSize, 10,10);
			}
			
			g2.drawImage(gp.player.inventory.get(i).image, slotX, slotY, null);
			slotX += gp.tileSize;
			if( i == 4 || i == 9 || i == 14) {
				slotX = slotXStart;
				slotY += gp.tileSize;
			}
		}
		
		
		int cursorX = slotXStart + (gp.tileSize * slotCol);
		int cursorY = slotYStart + (gp.tileSize * slotRow);
		int cursorWidth = gp.tileSize;
		int cursorHeight = gp.tileSize;
		
		g2.setColor(Color.white);
		g2.drawRoundRect(cursorX, cursorY, cursorWidth, cursorHeight, 10, 10);
	}
	
	public void currentEquip() {
		int x = gp.tileSize*5;
		int y = gp.tileSize/2;
		int width =  (gp.tileSize*4);
		int height = gp.tileSize *2 ;
		drawWindow(x,y,width,height);
		
		g2.setColor(Color.white);
		g2.setFont(g2.getFont().deriveFont(32F));
		int textX = x + 10;
		int textY = y + gp.tileSize;
				
		g2.drawString("Weapon: ", textX, textY);
		g2.setColor(Color.ORANGE);
		g2.fillRoundRect(textX +gp.tileSize*2, textY-gp.tileSize+20, gp.tileSize, gp.tileSize, 10,10);
		g2.drawImage(gp.player.currentWeapon.image, textX +gp.tileSize*2, textY-gp.tileSize+20, null);
		g2.setColor(Color.white);
		g2.drawString("Weapon deals: " + gp.player.currentWeapon.damage, textX, textY + gp.tileSize - 20);
	}

	public int getItemIndex() {
		int itemIndex = slotCol + (slotRow*5);
		return itemIndex;
	}
	
	public int drawXCentered(String text) {
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2 - length/2;
		return x;
	}
}
