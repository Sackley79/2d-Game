package main;

import java.awt.Rectangle;

public class EventRect extends Rectangle {

	int eventRecDefaultX, eventRecDefaultY;
	boolean eventDone = false;
	
}
