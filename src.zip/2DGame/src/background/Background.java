package background;

import java.awt.image.BufferedImage;

public class Background {

	public BufferedImage image;
	public boolean collision = false;
}
