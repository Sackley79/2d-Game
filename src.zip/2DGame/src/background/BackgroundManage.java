package background;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;

import main.GamePanel;

public class BackgroundManage {

	GamePanel gp; 
	public Background[] bg;
	public int mapBGNum[][];
	
	public BackgroundManage(GamePanel gp) {
		this.gp=gp;
		
		bg = new Background[15];
		mapBGNum = new int [gp.maxWorldCol][gp.maxWorldRow];
		
		getBackgroundImage();
		loadMap("/maps/FinalMap.txt");
		
	}
	
	public void getBackgroundImage() {
		
		try {
			bg[0] = new Background();
			bg[0].image = ImageIO.read(getClass().getResourceAsStream("/background/grass.png"));
			
			bg[1] = new Background();
			bg[1].image = ImageIO.read(getClass().getResourceAsStream("/background/water.png"));
			bg[1].collision = true;
			
			bg[2] = new Background();
			bg[2].image = ImageIO.read(getClass().getResourceAsStream("/background/wall.png"));
			bg[2].collision = true;
			
			bg[3] = new Background();
			bg[3].image = ImageIO.read(getClass().getResourceAsStream("/background/path.png"));
			
			bg[4] = new Background();
			bg[4].image = ImageIO.read(getClass().getResourceAsStream("/background/stone_floor.png"));
			
			bg[5] = new Background();
			bg[5].image = ImageIO.read(getClass().getResourceAsStream("/background/carpet1.png"));
			
			bg[6] = new Background();
			bg[6].image = ImageIO.read(getClass().getResourceAsStream("/background/tree.png"));
			bg[6].collision = true;
			
			bg[7] = new Background();
			bg[7].image = ImageIO.read(getClass().getResourceAsStream("/background/cave_floor.png"));
			
			bg[8] = new Background();
			bg[8].image = ImageIO.read(getClass().getResourceAsStream("/background/cave_rocks.png"));
			bg[8].collision = true;
			
			
			
			
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	public void loadMap(String map) {
		try {
			InputStream is = getClass().getResourceAsStream(map);
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			
			while(col<gp.maxWorldCol && row<gp.maxWorldRow) {
				String line = br.readLine();
				
				while(col<gp.maxWorldCol) {
					String num[] = line.split(" ");
					
					int number = Integer.parseInt(num[col]);
					
					mapBGNum [col][row] = number;
					
					col++;
				}
				if(col== gp.maxWorldCol) {
					col = 0;
					row++;
				}
			}
			br.close();
					
		}
		catch(Exception e) {
			
		}
	}
	
	public void draw(Graphics2D g2) {
		int worldCol = 0;
		int worldRow = 0;
		
		
		while(worldCol<gp.maxWorldCol && worldRow<gp.maxWorldRow ) {
			
			int BgNum = mapBGNum[worldCol][worldRow];
			
			int worldX = worldCol* gp.tileSize;
			int worldY = worldRow * gp.tileSize;
			int screenX = worldX - gp.player.worldX + gp.player.screenX;
			int screenY = worldY - gp.player.worldY + gp.player.screenY;
			
			//stop moving camera towards edge
//			if(gp.player.screenX > gp.player.worldX) {
//				screenX = worldX;
//			}
//			if(gp.player.screenY > gp.player.worldY) {
//				screenY = worldY;
//			}
//			
//			int rightOffSet = gp.screenWidth-gp.player.screenX;
//			if(rightOffSet > gp.worldWidth - gp.player.worldX) {
//				screenX=gp.screenWidth-gp.worldWidth-worldX;
//			}
//			int downOffSet = gp.screenHeight-gp.player.screenY;
//			if(downOffSet > gp.worldHeight - gp.player.worldY) {
//				screenY=gp.screenHeight-gp.worldHeight - worldY;
//			}
		
			if (worldX + gp.tileSize > gp.player.worldX - gp.player.screenX && 
				worldX - gp.tileSize< gp.player.worldX + gp.player.screenX && 
				worldY + gp.tileSize>gp.player.worldY - gp.player.screenY &&
				worldY - gp.tileSize< gp.player.worldY +  gp.player.screenY) {
				g2.drawImage(bg[BgNum].image, screenX, screenY,gp.tileSize, gp.tileSize, null);
			}
			
//			else if (gp.player.screenX > gp.player.worldX ||
//					gp.player.screenY > gp.player.worldY  ||
//					rightOffSet > gp.worldWidth - gp.player.worldX ||
//					downOffSet > gp.worldHeight - gp.player.worldY) {
//				g2.drawImage(bg[BgNum].image, screenX, screenY,gp.tileSize, gp.tileSize, null);
//			}
			
			worldCol++;

			
			if(worldCol==gp.maxWorldCol) {
				worldCol=0;
			
				worldRow++;
				
			}
		}
	}
}
